// Poke Extension Content Script
"use strict";
var Poke = (() => {
  // src/content/fiber.ts
  var HostComponent = 5;
  function getFiberFromElement(element) {
    const key = Object.keys(element).find(
      (k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$")
    );
    return key ? element[key] : null;
  }
  function getComponentName(fiber) {
    if (!fiber || !fiber.type) return null;
    if (typeof fiber.type === "string") {
      return fiber.type;
    }
    if (typeof fiber.type === "function") {
      return fiber.type.displayName || fiber.type.name || null;
    }
    if (fiber.type?.$$typeof === /* @__PURE__ */ Symbol.for("react.forward_ref")) {
      return fiber.type.displayName || fiber.type.render?.displayName || fiber.type.render?.name || null;
    }
    return null;
  }
  function extractSource(fiber) {
    const source = fiber?._debugSource;
    if (source) {
      return { filePath: source.fileName, line: source.lineNumber };
    }
    const debugStack = fiber?._debugStack;
    if (debugStack && debugStack.stack) {
      const result = parseSourceFromStack(debugStack.stack);
      if (result) return result;
    }
    return null;
  }
  var locationRegex = /:(\d+):\d+\)?$/;
  function parseSourceFromStack(stack) {
    const lines = stack.split("\n");
    let fallbackComponentName = null;
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("Error")) continue;
      if (trimmed.includes("react-stack-bottom-frame") || trimmed.includes("react_stack_bottom_frame")) break;
      if (trimmed.includes("node_modules") || trimmed.includes("react-dom")) continue;
      if (trimmed.includes("fakeJSXCallSite")) continue;
      const filePath = extractFilePath(trimmed);
      if (filePath) {
        const lineMatch = locationRegex.exec(trimmed);
        const lineNum = lineMatch ? parseInt(lineMatch[1], 10) : 0;
        return { filePath: decodeURIComponent(filePath.path), line: lineNum };
      }
      if (!fallbackComponentName) {
        const compName = extractComponentNameFromFrame(trimmed);
        if (compName) fallbackComponentName = compName;
      }
    }
    if (fallbackComponentName) {
      return { filePath: `<${fallbackComponentName}>`, line: 0 };
    }
    return null;
  }
  function extractFilePath(frame) {
    const aboutWebpackMatch = frame.match(/about:\/\/React\/Server\/webpack-internal:\/\/\/\([^)]+\)\/\.\/(.*?)(?:\?\d+)?:\d+:\d+/);
    if (aboutWebpackMatch) {
      return { path: aboutWebpackMatch[1] };
    }
    const aboutFileMatch = frame.match(/about:\/\/React\/Server\/file:\/\/\//);
    if (aboutFileMatch) {
      return null;
    }
    const webpackMatch = frame.match(/webpack-internal:\/\/\/\([^)]+\)\/\.\/(.*?)(?:\?\d+)?:\d+:\d+/);
    if (webpackMatch) {
      const p = webpackMatch[1];
      if (!p.includes("node_modules")) return { path: p };
    }
    const turboMatch = frame.match(/turbopack:\/\/\[project\]\/(.*?):\d+:\d+/);
    if (turboMatch) {
      const p = turboMatch[1];
      if (!p.includes("node_modules")) return { path: p };
    }
    const httpMatch = frame.match(/https?:\/\/[^/]+\/(.*?)(?:\?\S*)?:\d+:\d+/);
    if (httpMatch) {
      const p = httpMatch[1];
      if (!p.includes("node_modules") && !p.includes("_next/static")) return { path: p };
    }
    return null;
  }
  function extractComponentNameFromFrame(frame) {
    const match = frame.match(/at\s+([A-Z][A-Za-z0-9_$]*)\s+\(/);
    return match ? match[1] : null;
  }
  function getClassName(fiber) {
    try {
      const raw = fiber?.stateNode?.className ?? fiber?.memoizedProps?.className ?? "";
      let str = "";
      if (typeof raw === "string") {
        str = raw;
      } else if (raw && typeof raw === "object" && "baseVal" in raw) {
        str = raw.baseVal ?? "";
      } else if (raw) {
        str = String(raw);
      }
      return str.split(" ").filter((c) => !c.startsWith("poke-qa-")).join(" ");
    } catch {
      return "";
    }
  }
  function getSpacing(element) {
    const zero = { top: 0, right: 0, bottom: 0, left: 0 };
    if (!element || typeof window === "undefined") return { padding: { ...zero }, margin: { ...zero } };
    const style = window.getComputedStyle(element);
    return {
      padding: {
        top: parseFloat(style.paddingTop) || 0,
        right: parseFloat(style.paddingRight) || 0,
        bottom: parseFloat(style.paddingBottom) || 0,
        left: parseFloat(style.paddingLeft) || 0
      },
      margin: {
        top: parseFloat(style.marginTop) || 0,
        right: parseFloat(style.marginRight) || 0,
        bottom: parseFloat(style.marginBottom) || 0,
        left: parseFloat(style.marginLeft) || 0
      }
    };
  }
  var TEXT_TAGS = /* @__PURE__ */ new Set(["h1", "h2", "h3", "h4", "h5", "h6", "p", "span", "a", "li", "label", "button", "strong", "em", "small", "blockquote"]);
  function getFontInfo(element) {
    if (!element || typeof window === "undefined") return void 0;
    const tag = element.tagName.toLowerCase();
    if (!TEXT_TAGS.has(tag)) return void 0;
    const style = window.getComputedStyle(element);
    return {
      family: style.fontFamily.split(",")[0].trim().replace(/['"]/g, ""),
      size: style.fontSize,
      weight: style.fontWeight,
      lineHeight: style.lineHeight
    };
  }
  function getStyleInfo(element) {
    if (!element || typeof window === "undefined") return void 0;
    const s = window.getComputedStyle(element);
    const info = {};
    if (s.display && s.display !== "block" && s.display !== "inline") info.display = s.display;
    if (s.width && !s.width.startsWith("auto")) info.width = s.width;
    if (s.height && !s.height.startsWith("auto")) info.height = s.height;
    if (s.color) info.color = s.color;
    if (s.backgroundColor && s.backgroundColor !== "rgba(0, 0, 0, 0)") info.backgroundColor = s.backgroundColor;
    if (s.borderRadius && s.borderRadius !== "0px") info.borderRadius = s.borderRadius;
    if (s.gap && s.gap !== "normal") info.gap = s.gap;
    if (s.opacity && s.opacity !== "1") info.opacity = s.opacity;
    return Object.keys(info).length > 0 ? info : void 0;
  }
  function getCSSSelector(el) {
    if (el.id) return `#${el.id}`;
    const tag = el.tagName.toLowerCase();
    const classes = Array.from(el.classList).filter((c) => !c.startsWith("poke-qa-")).slice(0, 3);
    if (classes.length > 0) return `${tag}.${classes.join(".")}`;
    return tag;
  }
  function getElementLabel(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "button" || tag === "a" || tag === "label") {
      const text = el.textContent?.trim().slice(0, 30);
      if (text) return `${tag}("${text}")`;
    }
    if (el.id) return `#${el.id}`;
    const classes = Array.from(el.classList).filter((c) => !c.startsWith("poke-qa-")).slice(0, 2);
    if (classes.length > 0) return `${tag}.${classes.join(".")}`;
    return tag;
  }
  function extractSourceWithFallback(fiber) {
    const direct = extractSource(fiber);
    if (direct) return direct;
    let parent = fiber?.return;
    let depth = 0;
    while (parent && depth < 10) {
      const parentSource = extractSource(parent);
      if (parentSource) return parentSource;
      parent = parent.return;
      depth++;
    }
    const element = fiber?.stateNode;
    if (element instanceof Element) {
      return { filePath: getCSSSelector(element), line: 0 };
    }
    return { filePath: "unknown", line: 0 };
  }
  function fiberToTreeNode(fiber) {
    const name = getComponentName(fiber);
    if (!name) return null;
    const source = extractSourceWithFallback(fiber);
    const element = fiber.tag === HostComponent ? fiber.stateNode : null;
    const node = {
      componentName: name,
      filePath: source.filePath,
      line: source.line,
      className: getClassName(fiber),
      tag: typeof fiber.type === "string" ? fiber.type : "component",
      spacing: getSpacing(element)
    };
    const font = getFontInfo(element);
    if (font) node.font = font;
    const styles = getStyleInfo(element);
    if (styles) node.styles = styles;
    return node;
  }
  function getAncestors(fiber, maxDepth = 3) {
    const ancestors = [];
    let current = fiber?.return;
    while (current && ancestors.length < maxDepth) {
      const node = fiberToTreeNode(current);
      if (node && node.componentName !== "Fragment") {
        ancestors.unshift(node);
      }
      current = current.return;
    }
    return ancestors;
  }
  function getChildren(fiber, maxDepth = 2) {
    const children = [];
    function walk(f, depth) {
      if (!f || depth > maxDepth) return;
      let child = f.child;
      while (child) {
        const node = fiberToTreeNode(child);
        if (node) {
          children.push(node);
        }
        walk(child, depth + 1);
        child = child.sibling;
      }
    }
    walk(fiber, 1);
    return children;
  }
  function buildTree(element) {
    const fiber = getFiberFromElement(element);
    if (fiber) {
      const targetNode = fiberToTreeNode(fiber);
      if (!targetNode) return null;
      return {
        ancestors: getAncestors(fiber),
        target: targetNode,
        children: getChildren(fiber)
      };
    }
    return buildDOMTree(element);
  }
  function domElementToTreeNode(el) {
    return {
      componentName: getElementLabel(el),
      filePath: getCSSSelector(el),
      line: 0,
      className: Array.from(el.classList).filter((c) => !c.startsWith("poke-qa-")).join(" "),
      tag: el.tagName.toLowerCase(),
      spacing: getSpacing(el),
      font: getFontInfo(el),
      styles: getStyleInfo(el)
    };
  }
  function buildDOMTree(element) {
    const target = domElementToTreeNode(element);
    const ancestors = [];
    let parent = element.parentElement;
    while (parent && parent !== document.body && ancestors.length < 3) {
      ancestors.unshift(domElementToTreeNode(parent));
      parent = parent.parentElement;
    }
    const children = [];
    for (const child of Array.from(element.children).slice(0, 5)) {
      children.push(domElementToTreeNode(child));
    }
    return { ancestors, target, children };
  }

  // src/content/highlight.ts
  var marginOverlay = null;
  var paddingOverlay = null;
  var contentOverlay = null;
  var tooltip = null;
  var currentElement = null;
  var currentName = "";
  var scrollListener = null;
  function getOrCreate(id) {
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement("div");
      el.id = id;
      document.body.appendChild(el);
    }
    return el;
  }
  function applyPosition(element, name) {
    marginOverlay = getOrCreate("poke-highlight-margin");
    paddingOverlay = getOrCreate("poke-highlight-padding");
    contentOverlay = getOrCreate("poke-highlight-content");
    tooltip = getOrCreate("poke-tooltip");
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    const mt = parseFloat(style.marginTop) || 0;
    const mr = parseFloat(style.marginRight) || 0;
    const mb = parseFloat(style.marginBottom) || 0;
    const ml = parseFloat(style.marginLeft) || 0;
    const pt = parseFloat(style.paddingTop) || 0;
    const pr = parseFloat(style.paddingRight) || 0;
    const pb = parseFloat(style.paddingBottom) || 0;
    const pl = parseFloat(style.paddingLeft) || 0;
    const base = {
      position: "fixed",
      pointerEvents: "none",
      zIndex: "99998",
      display: "block",
      outline: "none",
      borderRadius: "0",
      boxShadow: "none"
    };
    const m = marginOverlay.style;
    Object.assign(m, base);
    m.left = rect.left - ml + "px";
    m.top = rect.top - mt + "px";
    m.width = rect.width + ml + mr + "px";
    m.height = rect.height + mt + mb + "px";
    m.background = "rgba(140, 111, 247, 0.12)";
    const p = paddingOverlay.style;
    Object.assign(p, base);
    p.left = rect.left + "px";
    p.top = rect.top + "px";
    p.width = rect.width + "px";
    p.height = rect.height + "px";
    p.background = "rgba(124, 58, 237, 0.18)";
    const c = contentOverlay.style;
    Object.assign(c, base);
    c.left = rect.left + pl + "px";
    c.top = rect.top + pt + "px";
    c.width = Math.max(0, rect.width - pl - pr) + "px";
    c.height = Math.max(0, rect.height - pt - pb) + "px";
    c.background = "rgba(140, 111, 247, 0.25)";
    const tooltipY = rect.top - mt > 28 ? rect.top - mt - 28 : rect.bottom + mb + 4;
    const t = tooltip.style;
    t.position = "fixed";
    t.pointerEvents = "none";
    t.zIndex = "99999";
    t.left = Math.max(0, rect.left - ml) + "px";
    t.top = Math.max(0, tooltipY) + "px";
    t.background = "rgba(30, 30, 36, 0.96)";
    t.color = "#f5f3ff";
    t.padding = "4px 10px";
    t.borderRadius = "8px";
    t.fontSize = "12px";
    t.fontWeight = "600";
    t.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
    t.whiteSpace = "nowrap";
    t.boxShadow = "0 4px 16px rgba(0, 0, 0, 0.4)";
    t.display = "block";
    tooltip.textContent = name;
  }
  function showHighlight(element, componentName) {
    currentElement = element;
    currentName = componentName;
    applyPosition(element, componentName);
    if (!scrollListener) {
      scrollListener = () => {
        if (currentElement) applyPosition(currentElement, currentName);
      };
      window.addEventListener("scroll", scrollListener, true);
    }
  }
  function hideHighlight() {
    if (marginOverlay) marginOverlay.style.display = "none";
    if (paddingOverlay) paddingOverlay.style.display = "none";
    if (contentOverlay) contentOverlay.style.display = "none";
    if (tooltip) tooltip.style.display = "none";
    currentElement = null;
    if (scrollListener) {
      window.removeEventListener("scroll", scrollListener, true);
      scrollListener = null;
    }
  }
  function cleanup() {
    hideHighlight();
    marginOverlay?.remove();
    paddingOverlay?.remove();
    contentOverlay?.remove();
    tooltip?.remove();
    marginOverlay = null;
    paddingOverlay = null;
    contentOverlay = null;
    tooltip = null;
  }

  // src/content/analytics.ts
  function track(event, params = {}) {
    window.postMessage({ type: "poke-track", event, params }, "*");
  }

  // src/content/inspector.ts
  var active = false;
  var onInspect = null;
  function handleMouseMove(e) {
    if (!active) return;
    const element = e.target;
    const fiber = getFiberFromElement(element);
    const name = fiber ? getComponentName(fiber) ?? element.tagName.toLowerCase() : element.tagName.toLowerCase();
    showHighlight(element, name);
  }
  function handleClick(e) {
    if (!active && !e.altKey) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    const element = e.target;
    const tree = buildTree(element);
    const fiber = getFiberFromElement(element);
    const name = fiber ? getComponentName(fiber) ?? element.tagName.toLowerCase() : element.tagName.toLowerCase();
    showHighlight(element, name);
    if (active) deactivate();
    if (onInspect && tree) {
      onInspect(element, tree);
    }
  }
  function handleKeyDown(e) {
    if (e.altKey && e.key === "p") {
      e.preventDefault();
      toggleInspectMode();
    }
    if (e.key === "Escape") {
      if (active) deactivate();
      hideHighlight();
    }
  }
  function showModeBanner() {
    let banner = document.getElementById("poke-mode-banner");
    if (!banner) {
      banner = document.createElement("div");
      banner.id = "poke-mode-banner";
      Object.assign(banner.style, {
        position: "fixed",
        top: "12px",
        left: "50%",
        transform: "translateX(-50%)",
        background: "linear-gradient(135deg, #8c6ff7, #7c3aed)",
        color: "white",
        padding: "8px 20px",
        borderRadius: "24px",
        fontSize: "13px",
        fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        fontWeight: "500",
        zIndex: "99999",
        boxShadow: "0 4px 24px rgba(0, 0, 0, 0.3)"
      });
      document.body.appendChild(banner);
    }
    banner.textContent = "POKEIT Inspector Active \u2014 Click to inspect, ESC to exit";
    banner.style.display = "block";
  }
  function hideModeBanner() {
    const banner = document.getElementById("poke-mode-banner");
    if (banner) banner.style.display = "none";
  }
  function activate() {
    active = true;
    document.body.style.cursor = "crosshair";
    showModeBanner();
    track("inspect_started");
  }
  function deactivate() {
    active = false;
    document.body.style.cursor = "";
    hideModeBanner();
  }
  function toggleInspectMode() {
    if (active) {
      deactivate();
      hideHighlight();
    } else {
      activate();
    }
  }
  function isActive() {
    return active;
  }
  function initInspector(callback) {
    onInspect = callback;
    document.addEventListener("mousemove", handleMouseMove, true);
    document.addEventListener("click", handleClick, true);
    document.addEventListener("keydown", handleKeyDown, true);
    return () => {
      document.removeEventListener("mousemove", handleMouseMove, true);
      document.removeEventListener("click", handleClick, true);
      document.removeEventListener("keydown", handleKeyDown, true);
      deactivate();
      hideHighlight();
      cleanup();
      onInspect = null;
    };
  }

  // src/content/spacing.ts
  var OVERLAP_THRESHOLD = 8;
  function detectSpacingOverlaps(ancestors, target) {
    const warnings = [];
    const sides = ["top", "right", "bottom", "left"];
    for (const ancestor of ancestors) {
      for (const side of sides) {
        const parentPad = ancestor.spacing.padding[side];
        const childPad = target.spacing.padding[side];
        if (parentPad >= OVERLAP_THRESHOLD && childPad >= OVERLAP_THRESHOLD) {
          const total = parentPad + childPad;
          warnings.push({
            type: "padding-overlap",
            parent: `${ancestor.componentName} (${getSpacingClass(ancestor.className, "p", side)})`,
            child: `${target.componentName} (${getSpacingClass(target.className, "p", side)})`,
            accumulated: `${side} ${total}px`
          });
        }
        const parentMar = ancestor.spacing.margin[side];
        const childMar = target.spacing.margin[side];
        if (parentMar >= OVERLAP_THRESHOLD && childMar >= OVERLAP_THRESHOLD) {
          const total = parentMar + childMar;
          warnings.push({
            type: "margin-overlap",
            parent: `${ancestor.componentName} (${getSpacingClass(ancestor.className, "m", side)})`,
            child: `${target.componentName} (${getSpacingClass(target.className, "m", side)})`,
            accumulated: `${side} ${total}px`
          });
        }
      }
    }
    return warnings;
  }
  function getSpacingClass(className, prefix, side) {
    const classes = className.split(/\s+/);
    const sidePrefix = {
      top: [`${prefix}t-`, `${prefix}y-`, `${prefix}-`],
      right: [`${prefix}r-`, `${prefix}x-`, `${prefix}-`],
      bottom: [`${prefix}b-`, `${prefix}y-`, `${prefix}-`],
      left: [`${prefix}l-`, `${prefix}x-`, `${prefix}-`]
    };
    for (const cls of classes) {
      for (const sp of sidePrefix[side]) {
        if (cls.startsWith(sp)) return cls;
      }
    }
    return `${prefix}-?`;
  }

  // src/content/utils.ts
  var HASH_PATTERNS = [
    /^css-/,
    /^_[a-z0-9]{4,}/i,
    /^r-[a-z0-9]+/,
    /^[a-f0-9]{6,}$/i,
    /^sc-[a-zA-Z]/,
    /^x[a-z0-9]{4,}$/
    // Meta/StyleX (e.g. xdj266r, x14z9mp)
  ];
  function isHashedClassName(className) {
    if (!className) return true;
    const classes = className.split(/\s+/).filter(Boolean);
    if (classes.length === 0) return true;
    const hashedCount = classes.filter((c) => HASH_PATTERNS.some((p) => p.test(c))).length;
    return hashedCount > classes.length / 2;
  }
  function fmtLoc(node) {
    if (!node.filePath || node.filePath === "unknown") return "";
    if (node.line === 0) return ` (${node.filePath})`;
    return ` (${node.filePath}:${node.line})`;
  }
  function fmtClass(node) {
    if (!node.className || isHashedClassName(node.className)) return "";
    return ` .${node.className.split(" ").slice(0, 3).join(".")}`;
  }
  function fallbackCopy(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    Object.assign(ta.style, { position: "fixed", left: "-9999px", opacity: "0" });
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  function copyToClipboard(text, onSuccess) {
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).then(onSuccess).catch(() => {
        fallbackCopy(text);
        onSuccess();
      });
    } else {
      fallbackCopy(text);
      onSuccess();
    }
  }

  // src/content/qa-store.ts
  var STORAGE_KEY = "poke-qa-items";
  var items = [];
  var listeners = /* @__PURE__ */ new Set();
  function notify() {
    save();
    syncToBridge();
    for (const fn of listeners) fn();
  }
  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
    }
  }
  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) items = JSON.parse(raw);
    } catch {
      items = [];
    }
  }
  function syncToBridge() {
    const exportData = items.map((item) => ({
      componentName: item.componentName,
      filePath: item.filePath,
      line: item.line,
      className: item.className,
      requests: item.requests
    }));
    const fullText = exportAsText();
    window.postMessage({ type: "poke-qa-sync", data: exportData, fullText }, "*");
  }
  function getUniqueSelector(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let current = el;
    while (current && current !== document.body && current !== document.documentElement) {
      let selector = current.tagName.toLowerCase();
      if (current.id) {
        parts.unshift(`#${CSS.escape(current.id)}`);
        break;
      }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(
          (c) => c.tagName === current.tagName
        );
        if (siblings.length > 1) {
          const idx = siblings.indexOf(current) + 1;
          selector += `:nth-of-type(${idx})`;
        }
      }
      parts.unshift(selector);
      current = parent;
    }
    return parts.join(" > ");
  }
  function init() {
    load();
    if (items.length > 0) {
      syncToBridge();
    }
  }
  function getAll() {
    return items;
  }
  function getBySelector(selector) {
    return items.find((item) => item.selector === selector);
  }
  function getByElement(el) {
    const selector = getUniqueSelector(el);
    return getBySelector(selector);
  }
  function addRequest(el, tree, request) {
    const selector = getUniqueSelector(el);
    let item = getBySelector(selector);
    if (item) {
      item.requests.push(request);
    } else {
      item = {
        id: crypto.randomUUID(),
        selector,
        filePath: tree.target.filePath,
        line: tree.target.line,
        componentName: tree.target.componentName,
        className: tree.target.className,
        requests: [request],
        tree,
        createdAt: Date.now()
      };
      items.push(item);
    }
    notify();
    return item;
  }
  function removeRequest(itemId, requestIndex) {
    const item = items.find((i) => i.id === itemId);
    if (!item) return;
    item.requests.splice(requestIndex, 1);
    if (item.requests.length === 0) {
      items = items.filter((i) => i.id !== itemId);
    }
    notify();
  }
  function clearAll() {
    items = [];
    notify();
  }
  function totalRequests() {
    return items.reduce((sum, item) => sum + item.requests.length, 0);
  }
  function onChange(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  }
  function resolveElement(item) {
    try {
      return document.querySelector(item.selector);
    } catch {
      return null;
    }
  }
  function fmtSpacing(node) {
    const p = node.spacing.padding;
    const m = node.spacing.margin;
    const parts = [];
    const pVals = [p.top, p.right, p.bottom, p.left];
    const mVals = [m.top, m.right, m.bottom, m.left];
    if (pVals.some((v) => v > 0)) {
      if (pVals.every((v) => v === pVals[0])) parts.push(`padding:${pVals[0]}px`);
      else if (p.top === p.bottom && p.left === p.right) parts.push(`padding:${p.top}px ${p.right}px`);
      else parts.push(`padding:${p.top}px ${p.right}px ${p.bottom}px ${p.left}px`);
    }
    if (mVals.some((v) => v > 0)) {
      if (mVals.every((v) => v === mVals[0])) parts.push(`margin:${mVals[0]}px`);
      else if (m.top === m.bottom && m.left === m.right) parts.push(`margin:${m.top}px ${m.right}px`);
      else parts.push(`margin:${m.top}px ${m.right}px ${m.bottom}px ${m.left}px`);
    }
    return parts.join("; ");
  }
  function fmtNodeFull(node) {
    const parts = [];
    const s = node.styles;
    if (s) {
      if (s.display) parts.push(`display:${s.display}`);
      if (s.width) parts.push(`width:${s.width}`);
      if (s.height) parts.push(`height:${s.height}`);
      if (s.gap) parts.push(`gap:${s.gap}`);
      if (s.borderRadius) parts.push(`border-radius:${s.borderRadius}`);
      if (s.color) parts.push(`color:${s.color}`);
      if (s.backgroundColor) parts.push(`bg:${s.backgroundColor}`);
      if (s.opacity) parts.push(`opacity:${s.opacity}`);
    }
    const sp = fmtSpacing(node);
    if (sp) parts.push(sp);
    if (node.font) {
      parts.push(`font:${node.font.family} ${node.font.weight} ${node.font.size}/${node.font.lineHeight}`);
    }
    return parts.length > 0 ? ` {${parts.join("; ")}}` : "";
  }
  function exportAsText() {
    if (items.length === 0) return "";
    const lines = [];
    lines.push("[POKEIT] QA Notes");
    lines.push(`URL: ${window.location.href}`);
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const tree = item.tree;
      const t = tree.target;
      lines.push("");
      lines.push(`## ${i + 1}. ${item.componentName}${fmtLoc(t)}`);
      for (let r = 0; r < item.requests.length; r++) {
        lines.push(`- ${item.requests[r]}`);
      }
      if (!isHashedClassName(item.className)) {
        lines.push(`Classes: ${item.className}`);
      }
      const targetStyles = fmtNodeFull(t);
      if (targetStyles) {
        lines.push(`Styles: ${targetStyles.slice(2, -1)}`);
      }
      lines.push("");
      lines.push("Component tree:");
      for (const ancestor of tree.ancestors) {
        const indent = "  ".repeat(tree.ancestors.indexOf(ancestor) + 1);
        lines.push(`${indent}${ancestor.componentName}${fmtLoc(ancestor)}${fmtClass(ancestor)}${fmtNodeFull(ancestor)}`);
      }
      const targetIndent = "  ".repeat(tree.ancestors.length + 1);
      lines.push(`${targetIndent}\u2605 ${t.componentName}${fmtLoc(t)}${fmtClass(t)}${fmtNodeFull(t)}`);
      for (const child of tree.children) {
        lines.push(`${targetIndent}  \u251C\u2500 ${child.componentName}${fmtLoc(child)}${fmtClass(child)}${fmtNodeFull(child)}`);
      }
      const warnings = detectSpacingOverlaps(tree.ancestors, tree.target);
      if (warnings.length > 0) {
        lines.push("Spacing warnings:");
        for (const w of warnings) {
          lines.push(`  ${w.type}: ${w.parent} + ${w.child} = ${w.accumulated}`);
        }
      }
    }
    lines.push("");
    lines.push("Fix all the above QA notes.");
    return lines.join("\n");
  }

  // src/content/qa-markers.ts
  var CONTAINER_ID = "poke-qa-markers";
  var container = null;
  var styleEl = null;
  var resizeObserver = null;
  function ensureContainer() {
    if (container) return;
    container = document.createElement("div");
    container.id = CONTAINER_ID;
    Object.assign(container.style, {
      position: "fixed",
      top: "0",
      left: "0",
      width: "0",
      height: "0",
      overflow: "visible",
      pointerEvents: "none",
      zIndex: "99998"
    });
    document.body.appendChild(container);
    styleEl = document.createElement("style");
    styleEl.textContent = `
    .poke-qa-pin {
      pointer-events: auto;
      cursor: pointer;
    }
    .poke-qa-pin:hover {
      transform: scale(1.15);
    }
    .poke-qa-pin:hover .poke-qa-tooltip {
      display: block;
    }
  `;
    document.head.appendChild(styleEl);
    window.addEventListener("scroll", repositionAll, true);
    window.addEventListener("resize", repositionAll);
    resizeObserver = new ResizeObserver(() => repositionAll());
    resizeObserver.observe(document.body);
  }
  var markers = [];
  function createMarkerDOM(item, index, rect) {
    const outline = document.createElement("div");
    Object.assign(outline.style, {
      position: "fixed",
      left: `${rect.left - 2}px`,
      top: `${rect.top - 2}px`,
      width: `${rect.width + 4}px`,
      height: `${rect.height + 4}px`,
      border: "2px dashed rgba(140, 111, 247, 0.35)",
      borderRadius: "8px",
      pointerEvents: "none"
    });
    const pin = document.createElement("div");
    pin.className = "poke-qa-pin";
    Object.assign(pin.style, {
      position: "fixed",
      left: `${rect.left - 10}px`,
      top: `${rect.top - 10}px`,
      width: "20px",
      height: "20px",
      background: "linear-gradient(135deg, #8c6ff7, #7c3aed)",
      color: "white",
      borderRadius: "50%",
      fontSize: "11px",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "600",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      boxShadow: "0 2px 8px rgba(140, 111, 247, 0.3)"
    });
    pin.textContent = String(index);
    const tooltip2 = document.createElement("div");
    tooltip2.className = "poke-qa-tooltip";
    Object.assign(tooltip2.style, {
      position: "absolute",
      top: "0",
      left: "24px",
      background: "rgba(30, 30, 36, 0.96)",
      color: "#f5f3ff",
      padding: "8px 12px",
      borderRadius: "10px",
      fontSize: "12px",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      whiteSpace: "pre-line",
      maxWidth: "260px",
      boxShadow: "0 4px 24px rgba(0, 0, 0, 0.4)",
      pointerEvents: "none",
      display: "none"
    });
    tooltip2.textContent = item.requests.join("\n");
    pin.appendChild(tooltip2);
    return { outline, pin };
  }
  function repositionAll() {
    for (const entry of markers) {
      const rect = entry.element.getBoundingClientRect();
      Object.assign(entry.outline.style, {
        left: `${rect.left - 2}px`,
        top: `${rect.top - 2}px`,
        width: `${rect.width + 4}px`,
        height: `${rect.height + 4}px`
      });
      Object.assign(entry.pin.style, {
        left: `${rect.left - 10}px`,
        top: `${rect.top - 10}px`
      });
    }
  }
  function addMarker(el, item) {
    ensureContainer();
    removeMarker(el);
    const rect = el.getBoundingClientRect();
    const index = markers.length + 1;
    const { outline, pin } = createMarkerDOM(item, index, rect);
    container.appendChild(outline);
    container.appendChild(pin);
    markers.push({ itemId: item.id, element: el, outline, pin });
  }
  function removeMarker(el) {
    const idx = markers.findIndex((m) => m.element === el);
    if (idx === -1) return;
    const entry = markers[idx];
    entry.outline.remove();
    entry.pin.remove();
    markers.splice(idx, 1);
  }
  function updateMarkerTooltip(el, item) {
    const entry = markers.find((m) => m.element === el);
    if (!entry) return;
    const tooltip2 = entry.pin.querySelector(".poke-qa-tooltip");
    if (tooltip2) tooltip2.textContent = item.requests.join("\n");
  }
  function clearAllMarkers() {
    for (const entry of markers) {
      entry.outline.remove();
      entry.pin.remove();
    }
    markers.length = 0;
  }
  function setMarkersVisible(visible) {
    if (container) {
      container.style.display = visible ? "" : "none";
    }
  }
  function restoreMarkers() {
    clearAllMarkers();
    const items2 = getAll();
    for (const item of items2) {
      const el = resolveElement(item);
      if (el) {
        addMarker(el, item);
      }
    }
  }

  // src/content/input-ui.ts
  var POPUP_ID = "poke-input-popup";
  var popup = null;
  var currentElement2 = null;
  var currentTree = null;
  var outsideClickHandler = null;
  var scrollHandler = null;
  function fmtFont(node) {
    if (!node.font) return "";
    return ` font:${node.font.family} ${node.font.weight} ${node.font.size}/${node.font.lineHeight}`;
  }
  function formatContextForClipboard(tree) {
    const spacingWarnings = detectSpacingOverlaps(tree.ancestors, tree.target);
    const lines = [];
    lines.push(`[POKEIT] Component Context`);
    lines.push(``);
    const hasFile = tree.target.filePath && tree.target.filePath !== "unknown";
    lines.push(`Target: ${tree.target.componentName}${hasFile ? ` (${tree.target.filePath}:${tree.target.line})` : ""}`);
    if (!isHashedClassName(tree.target.className)) {
      lines.push(`Classes: ${tree.target.className}`);
    }
    if (tree.target.font) {
      lines.push(`Font: ${tree.target.font.family} ${tree.target.font.weight} ${tree.target.font.size}/${tree.target.font.lineHeight}`);
    }
    lines.push(``);
    lines.push(`Tree:`);
    for (const ancestor of tree.ancestors) {
      const indent = "  ".repeat(tree.ancestors.indexOf(ancestor) + 1);
      lines.push(`${indent}${ancestor.componentName}${fmtLoc(ancestor)}${fmtClass(ancestor)}${fmtFont(ancestor)}`);
    }
    const targetIndent = "  ".repeat(tree.ancestors.length + 1);
    lines.push(`${targetIndent}\u2605 ${tree.target.componentName}${fmtLoc(tree.target)}${fmtClass(tree.target)}${fmtFont(tree.target)}`);
    for (const child of tree.children) {
      lines.push(`${targetIndent}  \u251C\u2500 ${child.componentName}${fmtLoc(child)}${fmtClass(child)}${fmtFont(child)}`);
    }
    if (spacingWarnings.length > 0) {
      lines.push(``);
      lines.push(`Spacing Warnings:`);
      for (const w of spacingWarnings) {
        lines.push(`  ${w.type}: ${w.parent} + ${w.child} = ${w.accumulated}`);
      }
    }
    return lines.join("\n");
  }
  function showCopyFeedback(button) {
    const original = button.textContent;
    button.textContent = "\u2713";
    button.style.color = "#4ade80";
    setTimeout(() => {
      button.textContent = original;
      button.style.color = "#9ca3af";
    }, 1200);
  }
  function buildExistingRequests(container3, item, element) {
    const wrapper = document.createElement("div");
    Object.assign(wrapper.style, {
      marginBottom: "8px",
      padding: "8px 10px",
      background: "rgba(46, 46, 54, 0.8)",
      borderRadius: "10px",
      maxHeight: "120px",
      overflowY: "auto",
      scrollbarWidth: "none"
    });
    const label = document.createElement("div");
    Object.assign(label.style, {
      fontSize: "11px",
      color: "#9390b0",
      marginBottom: "4px"
    });
    label.textContent = `Notes (${item.requests.length})`;
    wrapper.appendChild(label);
    for (let i = 0; i < item.requests.length; i++) {
      const row = document.createElement("div");
      Object.assign(row.style, {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "2px 0",
        fontSize: "12px"
      });
      const text = document.createElement("span");
      text.textContent = `\u2022 ${item.requests[i]}`;
      text.style.flex = "1";
      text.style.color = "#d4d0e8";
      const delBtn = document.createElement("button");
      delBtn.textContent = "\xD7";
      Object.assign(delBtn.style, {
        background: "transparent",
        color: "#9390b0",
        border: "none",
        cursor: "pointer",
        fontSize: "14px",
        padding: "0 4px",
        lineHeight: "1"
      });
      const idx = i;
      delBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        removeRequest(item.id, idx);
        const updatedItem = getByElement(element);
        if (updatedItem) {
          updateMarkerTooltip(element, updatedItem);
        }
        wrapper.remove();
        const refreshed = getByElement(element);
        if (refreshed && refreshed.requests.length > 0) {
          buildExistingRequests(container3, refreshed, element);
        }
      });
      row.appendChild(text);
      row.appendChild(delBtn);
      wrapper.appendChild(row);
    }
    const input = container3.querySelector("input");
    if (input) {
      container3.insertBefore(wrapper, input);
    } else {
      container3.appendChild(wrapper);
    }
  }
  function showInputPopup(element, tree) {
    cleanupPopup();
    currentElement2 = element;
    currentTree = tree;
    const rect = element.getBoundingClientRect();
    const popupW = 340;
    const popupH = 280;
    const pad = 10;
    const left = Math.max(pad, Math.min(rect.left, window.innerWidth - popupW - pad));
    const spaceBelow = window.innerHeight - rect.bottom - 8;
    const spaceAbove = rect.top - 8;
    const top = spaceBelow >= popupH ? rect.bottom + 8 : spaceAbove >= popupH ? rect.top - popupH - 8 : pad;
    popup = document.createElement("div");
    popup.id = POPUP_ID;
    Object.assign(popup.style, {
      position: "fixed",
      left: `${left}px`,
      top: `${top}px`,
      width: "340px",
      maxHeight: `${window.innerHeight - pad * 2}px`,
      overflowY: "auto",
      backgroundColor: "#1e1e24",
      color: "#f5f3ff",
      borderRadius: "16px",
      padding: "14px",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontSize: "13px",
      zIndex: "99999",
      boxShadow: "0 12px 48px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.06)"
    });
    const headerRow = document.createElement("div");
    Object.assign(headerRow.style, {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: "4px"
    });
    const header = document.createElement("div");
    Object.assign(header.style, { fontWeight: "600", flex: "1", minWidth: "0", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "inherit" });
    const headerLoc = tree.target.filePath && tree.target.filePath !== "unknown" ? tree.target.line > 0 ? ` (${tree.target.filePath}:${tree.target.line})` : ` (${tree.target.filePath})` : "";
    header.textContent = `\u2605 ${tree.target.componentName}${headerLoc}`;
    const copyBtn = document.createElement("button");
    copyBtn.textContent = "\u2398";
    copyBtn.title = "Copy component context";
    Object.assign(copyBtn.style, {
      flexShrink: "0",
      width: "32px",
      height: "32px",
      marginLeft: "8px",
      backgroundColor: "rgba(255, 255, 255, 0.06)",
      color: "#9390b0",
      border: "none",
      borderRadius: "8px",
      fontSize: "18px",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      lineHeight: "1",
      fontFamily: "inherit"
    });
    copyBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (!currentTree) return;
      const text = formatContextForClipboard(currentTree);
      copyToClipboard(text, () => showCopyFeedback(copyBtn));
    });
    headerRow.appendChild(header);
    headerRow.appendChild(copyBtn);
    popup.appendChild(headerRow);
    const classes = document.createElement("div");
    Object.assign(classes.style, {
      fontFamily: "monospace",
      fontSize: "11px",
      color: "#9390b0",
      marginBottom: "8px",
      wordBreak: "break-all"
    });
    const rawClass = tree.target.className || "";
    if (isHashedClassName(rawClass)) {
      const s = tree.target.styles;
      const sp = tree.target.spacing;
      const parts = [];
      if (s?.display) parts.push(s.display);
      if (s?.gap) parts.push(`gap: ${s.gap}`);
      if (sp?.padding) {
        const p = sp.padding;
        const vals = [p.top, p.right, p.bottom, p.left];
        if (vals.some((v) => v > 0)) parts.push(`p: ${vals.join(" ")}px`);
      }
      if (s?.borderRadius && s.borderRadius !== "0px") parts.push(`r: ${s.borderRadius}`);
      if (s?.width) parts.push(`w: ${s.width}`);
      if (s?.height) parts.push(`h: ${s.height}`);
      classes.textContent = parts.length > 0 ? parts.join(" \xB7 ") : "";
    } else {
      classes.textContent = rawClass;
    }
    if (!classes.textContent) classes.style.display = "none";
    popup.appendChild(classes);
    const existingItem = getByElement(element);
    if (existingItem && existingItem.requests.length > 0) {
      buildExistingRequests(popup, existingItem, element);
    }
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = existingItem ? "Add another note..." : "Add a note...";
    Object.assign(input.style, {
      width: "100%",
      padding: "10px 14px",
      backgroundColor: "rgba(255, 255, 255, 0.05)",
      color: "#f5f3ff",
      border: "none",
      borderRadius: "10px",
      fontSize: "13px",
      outline: "none",
      boxSizing: "border-box",
      fontFamily: "inherit"
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && input.value.trim()) {
        e.preventDefault();
        e.stopPropagation();
        const request = input.value.trim();
        const item = addRequest(element, tree, request);
        addMarker(element, item);
        track("note_added");
        hideInputPopup();
      }
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        hideInputPopup();
      }
    });
    popup.addEventListener("click", (e) => e.stopPropagation());
    popup.addEventListener("mousedown", (e) => e.stopPropagation());
    popup.appendChild(input);
    document.body.appendChild(popup);
    requestAnimationFrame(() => {
      input.focus();
      outsideClickHandler = (e) => {
        if (popup && !popup.contains(e.target)) {
          hideInputPopup();
        }
      };
      scrollHandler = () => {
        if (popup && currentElement2) {
          const r = currentElement2.getBoundingClientRect();
          const sb = window.innerHeight - r.bottom - 8;
          const sa = r.top - 8;
          const t = sb >= popupH ? r.bottom + 8 : sa >= popupH ? r.top - popupH - 8 : pad;
          popup.style.left = `${Math.max(pad, Math.min(r.left, window.innerWidth - popupW - pad))}px`;
          popup.style.top = `${t}px`;
        }
      };
      document.addEventListener("click", outsideClickHandler, true);
      window.addEventListener("scroll", scrollHandler, true);
    });
  }
  function cleanupPopup() {
    if (outsideClickHandler) {
      document.removeEventListener("click", outsideClickHandler, true);
      outsideClickHandler = null;
    }
    if (scrollHandler) {
      window.removeEventListener("scroll", scrollHandler, true);
      scrollHandler = null;
    }
    popup?.remove();
    popup = null;
    currentElement2 = null;
    currentTree = null;
  }
  function hideInputPopup() {
    cleanupPopup();
    hideHighlight();
  }

  // src/content/qa-panel.ts
  var BADGE_ID = "poke-qa-badge";
  var PANEL_ID = "poke-qa-panel";
  var INSPECT_BTN_ID = "poke-inspect-btn";
  var LOGO_SVG_DATA_URI = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 -120 3575 1000'%3E%3Cg transform='scale(1,-1) translate(0,-760)' fill='white'%3E%3Cpath d='M166-1Q121-1 93 28.5Q65 58 50 107.5Q35 157 30 216Q25 275 25 333Q25 401 43.5 466Q62 531 100.5 583.5Q139 636 198 667Q257 698 338 698Q420 698 486.5 664Q553 630 593 567Q633 504 633 417Q633 339 609 283Q585 227 544.5 191.5Q504 156 454.5 139Q405 122 354 123.5Q303 125 259 143Q264 119 264.5 94Q265 69 256.5 47.5Q248 26 226.5 12.5Q205-1 166-1ZM348 279Q384 279 410.5 305.5Q437 332 437 367Q437 403 410.5 429.5Q384 456 348 456Q312 456 285.5 429.5Q259 403 259 367Q259 332 285.5 305.5Q312 279 348 279Z'/%3E%3Cpath transform='translate(658,0)' d='M366-1Q297-2 236 24Q175 50 128 98Q81 146 54 210Q27 274 25 349Q24 421 50 484Q76 547 123 595Q170 643 232 670.5Q294 698 366 698Q435 699 496 673Q557 647 604 599.5Q651 552 678.5 488Q706 424 707 349Q709 277 682.5 214Q656 151 609 103.5Q562 56 499.5 28.5Q437 1 366-1ZM369 194Q413 194 446.5 226Q480 258 479 313Q479 369 446 401Q413 433 369 433Q325 433 292 401Q259 369 259 313Q259 258 292 226Q325 194 369 194Z'/%3E%3Cpath transform='translate(1390,0)' d='M137 0Q95 0 72 24.5Q49 49 39 89.5Q29 130 27 179Q25 228 25 277Q25 301 25.5 339.5Q26 378 26.5 418.5Q27 459 28 490.5Q29 522 30 534Q32 606 60 653Q88 700 143 700Q206 700 229.5 645.5Q253 591 253 489Q253 478 253 459Q272 494 299.5 535Q327 576 360 613Q393 650 430 673.5Q467 697 505 697Q552 697 582.5 661.5Q613 626 613 574Q613 527 585.5 482.5Q558 438 510 402Q462 366 398 343Q435 326 473 302.5Q511 279 542.5 250.5Q574 222 593 189Q612 156 612 118Q612 76 595.5 50Q579 24 553 12Q527 0 498 0Q447 0 403 33Q359 66 321.5 119Q284 172 252 230Q252 186 248.5 145Q245 104 234 71Q223 38 200 19Q177 0 137 0Z'/%3E%3Cpath transform='translate(2028,0)' d='M367 0Q326 0 279.5 6Q233 12 188 31Q143 50 106 87Q69 124 47 185.5Q25 247 25 338Q25 438 59 520Q93 602 162 651Q231 700 335 700Q410 700 457.5 687Q505 674 532 653Q559 632 569.5 607Q580 582 580 557Q580 531 566.5 507Q553 483 524 469Q496 456 466 457.5Q436 459 412 459Q360 459 330.5 440.5Q301 422 289 384Q305 385 324.5 385.5Q344 386 365 386Q406 386 443.5 384.5Q481 383 496 380Q531 373 549 352.5Q567 332 567 306Q567 281 550 261Q533 241 495 233Q481 230 441.5 228.5Q402 227 359 227Q342 227 326 227.5Q310 228 297 228Q311 197 339.5 179.5Q368 162 413 162Q430 162 462 165.5Q494 169 524 160Q572 145 572 97Q572 71 554.5 48.5Q537 26 492.5 13Q448 0 367 0Z'/%3E%3Cpath transform='translate(2633,0)' d='M165 700Q213 700 240 677Q267 654 278 618.5Q289 583 289 546Q289 514 285 473Q281 432 272.5 390.5Q264 349 251 313Q244 291 223 271Q202 251 165 251Q128 251 107 271Q86 291 78 313Q65 349 56.5 390.5Q48 432 44 473Q40 514 40 546Q41 583 52 618.5Q63 654 89.5 677Q116 700 165 700ZM164 5Q136 5 112.5 19.5Q89 34 74.5 57.5Q60 81 60 109Q60 137 74.5 160.5Q89 184 112.5 198.5Q136 213 164 213Q192 213 215.5 198.5Q239 184 253.5 160.5Q268 137 268 109Q268 81 253.5 57.5Q239 34 215.5 19.5Q192 5 164 5Z'/%3E%3Cpath transform='translate(2962,0)' d='M90 700Q0 700 0 610Q0 520 90 520L175 520Q180 520 180 505Q180 450 180 370Q180 290 178 225Q176 160 168 107.5Q160 55 185 27.5Q210 0 285 0Q360 0 385 27.5Q410 55 402 107.5Q394 160 392 225Q390 290 390 370Q390 450 390 505Q390 520 395 520L480 520Q570 520 570 610Q570 700 480 700Z'/%3E%3C/g%3E%3C/svg%3E";
  var C = {
    bg: "rgba(30, 30, 36, 0.96)",
    bgCard: "rgba(255, 255, 255, 0.04)",
    text: "#f5f3ff",
    textMuted: "#9390b0",
    accent: "#8c6ff7",
    accentHover: "#a78bfa",
    btnBg: "#8c6ff7",
    danger: "rgba(239, 68, 68, 0.12)",
    dangerText: "#f87171"
  };
  var container2 = null;
  var badge = null;
  var panel = null;
  var inspectBtn = null;
  var panelOpen = false;
  var overlayVisible = true;
  function copyToClipboard2(text, button) {
    const copy = () => {
      const original = button.textContent;
      button.textContent = "\u2713";
      button.style.color = "#4ade80";
      setTimeout(() => {
        button.textContent = original;
        button.style.color = "#ffffff";
      }, 1200);
    };
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).then(copy).catch(() => {
        fallbackCopy2(text);
        copy();
      });
    } else {
      fallbackCopy2(text);
      copy();
    }
  }
  function fallbackCopy2(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    Object.assign(ta.style, { position: "fixed", left: "-9999px", opacity: "0" });
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  function injectFont() {
  }
  function createContainer() {
    if (container2) return;
    container2 = document.createElement("div");
    Object.assign(container2.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      zIndex: "99997",
      display: overlayVisible ? "flex" : "none",
      alignItems: "center",
      gap: "8px"
    });
    document.body.appendChild(container2);
  }
  function hideOverlayViaToggle() {
    setOverlayVisible(false);
    window.postMessage({ type: "poke-overlay-state-changed", visible: false }, "*");
  }
  function createInspectBtn() {
    if (inspectBtn) return;
    inspectBtn = document.createElement("div");
    inspectBtn.id = INSPECT_BTN_ID;
    Object.assign(inspectBtn.style, {
      background: C.btnBg,
      padding: "8px 14px",
      borderRadius: "24px",
      cursor: "pointer",
      boxShadow: "0 4px 24px rgba(0, 0, 0, 0.35)",
      backdropFilter: "blur(16px)",
      WebkitBackdropFilter: "blur(16px)",
      userSelect: "none",
      transition: "all 0.2s ease",
      display: "flex",
      alignItems: "center",
      gap: "6px"
    });
    const logo = document.createElement("img");
    logo.src = LOGO_SVG_DATA_URI;
    logo.style.height = "16px";
    logo.style.display = "block";
    inspectBtn.appendChild(logo);
    inspectBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleInspectMode();
      updateInspectBtn();
    });
    const minBtn = document.createElement("div");
    Object.assign(minBtn.style, {
      width: "16px",
      height: "16px",
      borderRadius: "50%",
      background: "rgba(255, 255, 255, 0.15)",
      color: "rgba(255, 255, 255, 0.6)",
      fontSize: "10px",
      lineHeight: "16px",
      textAlign: "center",
      cursor: "pointer",
      flexShrink: "0",
      transition: "all 0.15s ease"
    });
    minBtn.textContent = "\u2715";
    minBtn.title = "Hide overlay (\u2325P to show again)";
    minBtn.addEventListener("mouseenter", () => {
      minBtn.style.background = "rgba(255, 255, 255, 0.25)";
      minBtn.style.color = "rgba(255, 255, 255, 0.9)";
    });
    minBtn.addEventListener("mouseleave", () => {
      minBtn.style.background = "rgba(255, 255, 255, 0.15)";
      minBtn.style.color = "rgba(255, 255, 255, 0.6)";
    });
    minBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      hideOverlayViaToggle();
    });
    inspectBtn.appendChild(minBtn);
    container2?.appendChild(inspectBtn);
  }
  function updateInspectBtn() {
    if (!inspectBtn) return;
    let status = inspectBtn.querySelector("span");
    if (!status) {
      status = document.createElement("span");
      Object.assign(status.style, {
        fontSize: "11px",
        fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        color: "#ffffff",
        fontWeight: "500"
      });
      inspectBtn.appendChild(status);
    }
    if (isActive()) {
      inspectBtn.style.background = "linear-gradient(135deg, #7c3aed, #6d28d9)";
      status.textContent = "Inspecting...";
      status.style.display = "inline";
    } else {
      inspectBtn.style.background = C.btnBg;
      status.textContent = "";
      status.style.display = "none";
    }
  }
  function createBadge() {
    if (badge) return;
    badge = document.createElement("div");
    badge.id = BADGE_ID;
    Object.assign(badge.style, {
      background: C.btnBg,
      color: C.text,
      padding: "8px 14px",
      borderRadius: "24px",
      fontSize: "14px",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      fontWeight: "700",
      lineHeight: "16px",
      letterSpacing: "-0.3px",
      cursor: "pointer",
      boxShadow: "0 4px 24px rgba(0, 0, 0, 0.35)",
      backdropFilter: "blur(16px)",
      WebkitBackdropFilter: "blur(16px)",
      userSelect: "none",
      display: "none",
      transition: "all 0.2s ease"
    });
    badge.addEventListener("click", (e) => {
      e.stopPropagation();
      togglePanel();
    });
    if (container2 && inspectBtn) {
      container2.insertBefore(badge, inspectBtn);
    } else {
      container2?.appendChild(badge);
    }
  }
  function togglePanel() {
    if (panelOpen) {
      closePanel();
    } else {
      openPanel();
    }
  }
  function openPanel() {
    closePanel();
    panelOpen = true;
    const items2 = getAll();
    const totalReqs = totalRequests();
    panel = document.createElement("div");
    panel.id = PANEL_ID;
    Object.assign(panel.style, {
      position: "fixed",
      bottom: "72px",
      right: "20px",
      width: "320px",
      maxHeight: "400px",
      overflowY: "auto",
      scrollbarWidth: "none",
      background: C.bg,
      color: C.text,
      borderRadius: "16px",
      padding: "14px",
      fontSize: "13px",
      fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      zIndex: "99997",
      boxShadow: "0 12px 48px rgba(0, 0, 0, 0.5)",
      backdropFilter: "blur(20px)",
      WebkitBackdropFilter: "blur(20px)"
    });
    const header = document.createElement("div");
    Object.assign(header.style, {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "12px"
    });
    const title = document.createElement("div");
    title.style.fontWeight = "600";
    title.textContent = `Notes (${totalReqs})`;
    const resetBtn = document.createElement("button");
    resetBtn.textContent = "Reset all";
    Object.assign(resetBtn.style, {
      background: C.danger,
      color: C.dangerText,
      border: "none",
      borderRadius: "8px",
      padding: "4px 10px",
      fontSize: "12px",
      cursor: "pointer",
      fontFamily: "inherit"
    });
    resetBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      clearAll();
      clearAllMarkers();
      closePanel();
    });
    header.appendChild(title);
    header.appendChild(resetBtn);
    panel.appendChild(header);
    if (items2.length === 0) {
      const empty = document.createElement("div");
      empty.style.color = C.textMuted;
      empty.textContent = "No notes yet.";
      panel.appendChild(empty);
    } else {
      for (const item of items2) {
        const row = document.createElement("div");
        Object.assign(row.style, {
          marginBottom: "8px",
          padding: "10px",
          background: C.bgCard,
          borderRadius: "10px"
        });
        const comp = document.createElement("div");
        comp.style.fontWeight = "500";
        comp.style.marginBottom = "4px";
        comp.textContent = `${item.componentName} (${item.filePath}:${item.line})`;
        row.appendChild(comp);
        const cls = document.createElement("div");
        Object.assign(cls.style, {
          fontSize: "11px",
          color: C.textMuted,
          fontFamily: "monospace",
          marginBottom: "4px",
          wordBreak: "break-all"
        });
        cls.textContent = item.className || "(no classes)";
        row.appendChild(cls);
        for (let i = 0; i < item.requests.length; i++) {
          const reqRow = document.createElement("div");
          Object.assign(reqRow.style, {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            fontSize: "12px",
            padding: "2px 0"
          });
          const reqText = document.createElement("span");
          reqText.textContent = `\u2022 ${item.requests[i]}`;
          reqText.style.flex = "1";
          const delBtn = document.createElement("button");
          delBtn.textContent = "\xD7";
          Object.assign(delBtn.style, {
            background: "transparent",
            color: C.textMuted,
            border: "none",
            cursor: "pointer",
            fontSize: "14px",
            padding: "0 4px",
            lineHeight: "1"
          });
          delBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            removeRequest(item.id, i);
            openPanel();
          });
          reqRow.appendChild(reqText);
          reqRow.appendChild(delBtn);
          row.appendChild(reqRow);
        }
        panel.appendChild(row);
      }
    }
    const footer = document.createElement("div");
    Object.assign(footer.style, { marginTop: "12px" });
    const copyBtn = document.createElement("button");
    copyBtn.textContent = "Copy all notes for AI agent";
    Object.assign(copyBtn.style, {
      width: "100%",
      background: "linear-gradient(135deg, #8c6ff7, #7c3aed)",
      color: "#ffffff",
      border: "none",
      borderRadius: "10px",
      padding: "10px 14px",
      fontSize: "12px",
      cursor: "pointer",
      fontFamily: "inherit",
      fontWeight: "500"
    });
    copyBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const text = exportAsText();
      if (text) {
        copyToClipboard2(text, copyBtn);
        track("notes_copied", { count: totalRequests() });
      }
    });
    footer.appendChild(copyBtn);
    const screenshotBtn = document.createElement("button");
    screenshotBtn.textContent = "Download screenshot";
    Object.assign(screenshotBtn.style, {
      width: "100%",
      marginTop: "6px",
      background: "transparent",
      color: C.text,
      border: `1px solid rgba(140, 111, 247, 0.25)`,
      borderRadius: "10px",
      padding: "10px 14px",
      fontSize: "12px",
      cursor: "pointer",
      fontFamily: "inherit",
      fontWeight: "500",
      transition: "all 0.15s ease"
    });
    screenshotBtn.addEventListener("mouseenter", () => {
      screenshotBtn.style.borderColor = "rgba(140, 111, 247, 0.5)";
    });
    screenshotBtn.addEventListener("mouseleave", () => {
      screenshotBtn.style.borderColor = "rgba(140, 111, 247, 0.25)";
    });
    screenshotBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      screenshotBtn.textContent = "Capturing...";
      screenshotBtn.style.opacity = "0.6";
      const timeout = setTimeout(() => {
        window.removeEventListener("message", onResult);
        screenshotBtn.textContent = "Failed: no response";
        screenshotBtn.style.color = C.dangerText;
        screenshotBtn.style.opacity = "1";
        setTimeout(() => {
          screenshotBtn.textContent = "Download screenshot";
          screenshotBtn.style.color = C.text;
        }, 3e3);
      }, 5e3);
      const onResult = (event) => {
        if (event.data?.type !== "poke-screenshot-result") return;
        window.removeEventListener("message", onResult);
        clearTimeout(timeout);
        if (event.data.ok) {
          screenshotBtn.textContent = "\u2713 Saved";
          screenshotBtn.style.color = "#4ade80";
          track("screenshot_taken");
        } else {
          screenshotBtn.textContent = event.data.error ? `Failed: ${event.data.error}` : "Failed";
          screenshotBtn.style.color = C.dangerText;
        }
        screenshotBtn.style.opacity = "1";
        setTimeout(() => {
          screenshotBtn.textContent = "Download screenshot";
          screenshotBtn.style.color = C.text;
        }, 3e3);
      };
      window.addEventListener("message", onResult);
      window.postMessage({
        type: "poke-screenshot",
        hostname: window.location.hostname
      }, "*");
    });
    footer.appendChild(screenshotBtn);
    const help = document.createElement("div");
    Object.assign(help.style, {
      marginTop: "8px",
      fontSize: "11px",
      color: C.textMuted,
      lineHeight: "1.5"
    });
    help.textContent = "\u2325P to inspect \u2192 Click component \u2192 Add note \u2192 Paste into your AI agent";
    footer.appendChild(help);
    panel.appendChild(footer);
    panel.addEventListener("click", (e) => e.stopPropagation());
    document.body.appendChild(panel);
  }
  function closePanel() {
    panelOpen = false;
    panel?.remove();
    panel = null;
  }
  function setOverlayVisible(visible) {
    overlayVisible = visible;
    if (visible) {
      if (container2) container2.style.display = "flex";
      updateBadge();
    } else {
      if (container2) container2.style.display = "none";
      closePanel();
    }
    setMarkersVisible(visible);
  }
  function updateBadge() {
    createBadge();
    if (!badge) return;
    const n = totalRequests();
    if (n === 0 || !overlayVisible) {
      badge.style.display = "none";
      closePanel();
    } else {
      badge.style.display = "block";
      badge.textContent = `Notes (${n})`;
    }
  }
  function initPanel() {
    injectFont();
    createContainer();
    createInspectBtn();
    createBadge();
    updateBadge();
    onChange(() => {
      updateBadge();
      if (panelOpen) {
        openPanel();
      }
    });
    document.addEventListener("click", () => {
      if (panelOpen) closePanel();
    });
    document.addEventListener("keydown", () => {
      requestAnimationFrame(() => updateInspectBtn());
    });
    window.addEventListener("message", (event) => {
      if (event.source !== window) return;
      if (event.data?.type === "poke-overlay-toggle") {
        const visible = event.data.visible !== void 0 ? event.data.visible : !overlayVisible;
        setOverlayVisible(visible);
      }
    });
  }
  function destroyPanel() {
    closePanel();
    badge?.remove();
    badge = null;
    inspectBtn?.remove();
    inspectBtn = null;
    container2?.remove();
    container2 = null;
  }

  // src/content/index.ts
  var cleanup2 = null;
  var routeObserver = null;
  function loadFont() {
  }
  function init2() {
    if (cleanup2) return;
    loadFont();
    init();
    requestAnimationFrame(() => {
      restoreMarkers();
      initPanel();
    });
    watchRouteChanges();
    cleanup2 = initInspector(async (element, tree) => {
      if (!tree) return;
      deactivate();
      updateInspectBtn();
      showInputPopup(element, tree);
    });
    console.log("[POKEIT] Inspector initialized. Alt+Click to inspect, Option+P to toggle mode.");
  }
  function watchRouteChanges() {
    window.addEventListener("popstate", () => {
      requestAnimationFrame(() => restoreMarkers());
    });
    const target = document.getElementById("__next") || document.body;
    routeObserver = new MutationObserver((mutations) => {
      const significant = mutations.some(
        (m) => m.type === "childList" && m.addedNodes.length > 0
      );
      if (significant) {
        requestAnimationFrame(() => restoreMarkers());
      }
    });
    routeObserver.observe(target, { childList: true, subtree: true });
  }
  function destroy() {
    cleanup2?.();
    cleanup2 = null;
    hideInputPopup();
    destroyPanel();
    routeObserver?.disconnect();
    routeObserver = null;
  }
  console.log("[POKEIT] Content script loaded. readyState:", document.readyState);
  if (typeof window !== "undefined") {
    if (window.__POKE_INITIALIZED__) {
      console.log("[POKEIT] Already initialized \u2014 skipping.");
    } else {
      window.__POKE_INITIALIZED__ = true;
      window.__POKE_INIT__ = init2;
      window.__POKE_DESTROY__ = destroy;
      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => init2());
      } else {
        init2();
      }
    }
  }
})();
