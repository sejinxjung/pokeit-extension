"use strict";

// src/popup/popup.ts
var sitesList = document.getElementById("sites-list");
var emptyState = document.getElementById("empty-state");
var overlayToggle = document.getElementById("overlay-toggle");
var refreshHint = document.getElementById("refresh-hint");
async function ensureInjected(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content-bridge.js"]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content-main.global.js"],
      world: "MAIN"
    });
    return true;
  } catch {
    return false;
  }
}
async function sendOverlayToggle(tabId, visible) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "poke-overlay-toggle",
      visible
    });
    return true;
  } catch {
    return false;
  }
}
function showRefreshHint(show) {
  if (refreshHint) refreshHint.style.display = show ? "block" : "none";
}
function timeAgo(ms) {
  const sec = Math.round(ms / 1e3);
  if (sec < 60) return "just now";
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const days = Math.floor(hr / 24);
  return `${days}d ago`;
}
function noteCount(data) {
  return data.reduce((sum, item) => sum + (item.requests?.length || 0), 0);
}
function getSiteText(info) {
  if (info.fullText) return info.fullText;
  const lines = [];
  lines.push("[POKEIT] QA Notes");
  lines.push(`URL: ${info.url}`);
  lines.push("");
  lines.push("| # | Component | Location | Note |");
  lines.push("|---|-----------|----------|------|");
  let idx = 1;
  for (const item of info.data) {
    const loc = item.filePath && item.filePath !== "unknown" ? item.line > 0 ? `${item.filePath}:${item.line}` : item.filePath : item.componentName;
    for (const req of item.requests || []) {
      lines.push(`| ${idx} | ${item.componentName} | ${loc} | ${req} |`);
      idx++;
    }
  }
  lines.push("");
  lines.push("Fix all the above QA notes.");
  return lines.join("\n");
}
function deleteSite(origin) {
  chrome.runtime.sendMessage({ type: "poke-delete-origin", origin }, () => {
    renderSites();
  });
}
function copyText(text, button) {
  const done = () => {
    const orig = button.textContent;
    button.textContent = "\u2713";
    button.style.color = "#4ade80";
    setTimeout(() => {
      button.textContent = orig;
      button.style.color = "";
    }, 1200);
  };
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => done());
  } else {
    done();
  }
}
function renderSites() {
  if (!sitesList || !emptyState) return;
  chrome.storage.local.get(["qaByOrigin"], (result) => {
    const byOrigin = result.qaByOrigin || {};
    const origins = Object.entries(byOrigin).filter(([, v]) => v.data && v.data.length > 0).sort(([, a], [, b]) => b.updatedAt - a.updatedAt);
    sitesList.innerHTML = "";
    if (origins.length === 0) {
      emptyState.style.display = "block";
      return;
    }
    emptyState.style.display = "none";
    for (const [origin, info] of origins) {
      let host;
      try {
        host = new URL(origin).host;
      } catch {
        continue;
      }
      const count = noteCount(info.data);
      const ago = timeAgo(Date.now() - info.updatedAt);
      const card = document.createElement("div");
      card.className = "site-card";
      const dot = document.createElement("div");
      dot.className = "site-dot";
      const siteInfo = document.createElement("div");
      siteInfo.className = "site-info";
      const hostEl = document.createElement("div");
      hostEl.className = "site-host";
      hostEl.textContent = host;
      const metaEl = document.createElement("div");
      metaEl.className = "site-meta";
      metaEl.textContent = `${count} note${count !== 1 ? "s" : ""} \xB7 ${ago}`;
      siteInfo.appendChild(hostEl);
      siteInfo.appendChild(metaEl);
      const actions = document.createElement("div");
      actions.className = "site-actions";
      const cpBtn = document.createElement("button");
      cpBtn.className = "site-action-btn";
      cpBtn.title = "Copy notes";
      cpBtn.textContent = "\u2398";
      cpBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const text = getSiteText(info);
        copyText(text, cpBtn);
      });
      const delBtn = document.createElement("button");
      delBtn.className = "site-action-btn site-action-del";
      delBtn.title = "Delete site";
      delBtn.textContent = "\u2715";
      delBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        deleteSite(origin);
      });
      actions.appendChild(cpBtn);
      actions.appendChild(delBtn);
      card.appendChild(dot);
      card.appendChild(siteInfo);
      card.appendChild(actions);
      sitesList.appendChild(card);
    }
  });
}
if (overlayToggle) {
  chrome.storage.local.get(["overlayVisible"], async (result) => {
    const visible = result.overlayVisible === true;
    overlayToggle.checked = visible;
    if (visible) {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = tabs[0]?.id;
      if (tabId) {
        const injected = await ensureInjected(tabId);
        if (injected) {
          const delivered = await sendOverlayToggle(tabId, true);
          showRefreshHint(!delivered);
        } else {
          showRefreshHint(true);
        }
      }
    }
  });
  overlayToggle.addEventListener("change", async () => {
    const visible = overlayToggle.checked;
    chrome.storage.local.set({ overlayVisible: visible });
    showRefreshHint(false);
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs[0]?.id;
    if (tabId) {
      const injected = await ensureInjected(tabId);
      if (injected) {
        const delivered = await sendOverlayToggle(tabId, visible);
        showRefreshHint(visible && !delivered);
      } else {
        showRefreshHint(visible);
      }
    }
  });
}
renderSites();
