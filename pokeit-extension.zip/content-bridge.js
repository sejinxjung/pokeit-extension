"use strict";

// src/content-bridge.ts
if (globalThis.__POKE_BRIDGE_INITIALIZED__) {
} else {
  let alive = function() {
    return !!chrome.runtime?.id;
  }, safeSend = function(msg, cb) {
    if (!alive()) return;
    try {
      if (cb) {
        chrome.runtime.sendMessage(msg, cb);
      } else {
        chrome.runtime.sendMessage(msg);
      }
    } catch {
    }
  };
  alive2 = alive, safeSend2 = safeSend;
  globalThis.__POKE_BRIDGE_INITIALIZED__ = true;
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "poke-qa-sync") return;
    safeSend({
      type: "poke-qa-sync",
      data: event.data.data,
      fullText: event.data.fullText || "",
      url: window.location.href
    }, () => {
    });
  });
  try {
    chrome.runtime.onMessage.addListener((message) => {
      if (!alive()) return;
      if (message.type === "poke-overlay-toggle") {
        window.postMessage({
          type: "poke-overlay-toggle",
          visible: message.visible
        }, "*");
      }
    });
  } catch {
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "poke-overlay-state-changed") return;
    if (alive()) {
      try {
        chrome.storage.local.set({ overlayVisible: event.data.visible });
      } catch {
      }
    }
  });
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "poke-screenshot") return;
    safeSend(
      { type: "poke-screenshot", hostname: event.data.hostname },
      (response) => {
        window.postMessage({
          type: "poke-screenshot-result",
          ok: response?.ok ?? false,
          error: response?.error
        }, "*");
      }
    );
  });
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "poke-track") return;
    safeSend({
      type: "poke-track",
      event: event.data.event,
      params: event.data.params
    });
  });
  if (alive()) {
    try {
      chrome.storage.local.get(["overlayVisible"], (result) => {
        const visible = result.overlayVisible === true;
        window.postMessage({
          type: "poke-overlay-toggle",
          visible
        }, "*");
      });
    } catch {
    }
  }
}
var alive2;
var safeSend2;
