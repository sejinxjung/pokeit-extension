"use strict";

// src/background.ts
var injectedTabs = /* @__PURE__ */ new Set();
async function injectScripts(tabId) {
  if (injectedTabs.has(tabId)) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content-bridge.js"]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content-main.global.js"],
      world: "MAIN"
    });
    injectedTabs.add(tabId);
  } catch {
  }
}
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  await injectScripts(tab.id);
  chrome.tabs.sendMessage(tab.id, { type: "poke-overlay-toggle" });
});
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== "toggle-inspect" || !tab?.id) return;
  await injectScripts(tab.id);
  chrome.tabs.sendMessage(tab.id, { type: "poke-overlay-toggle" });
});
chrome.tabs.onRemoved.addListener((tabId) => {
  injectedTabs.delete(tabId);
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    injectedTabs.delete(tabId);
  }
});
var GA_MEASUREMENT_ID = "G-XXXXXXXXXX";
var GA_API_SECRET = "";
async function getClientId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["gaClientId"], (result) => {
      if (result.gaClientId) {
        resolve(result.gaClientId);
      } else {
        const clientId = crypto.randomUUID();
        chrome.storage.local.set({ gaClientId: clientId });
        resolve(clientId);
      }
    });
  });
}
async function trackEvent(name, params = {}) {
  if (!GA_API_SECRET) return;
  const clientId = await getClientId();
  const body = {
    client_id: clientId,
    events: [{ name, params }]
  };
  fetch(
    `https://www.google-analytics.com/mp/collect?measurement_id=${GA_MEASUREMENT_ID}&api_secret=${GA_API_SECRET}`,
    {
      method: "POST",
      body: JSON.stringify(body)
    }
  ).catch(() => {
  });
}
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    trackEvent("extension_installed");
  } else if (details.reason === "update") {
    trackEvent("extension_updated", { version: chrome.runtime.getManifest().version });
  }
});
var syncQueue = Promise.resolve();
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "poke-qa-sync") {
    let origin;
    try {
      origin = new URL(message.url).origin;
    } catch {
      return;
    }
    syncQueue = syncQueue.then(() => new Promise((resolve) => {
      chrome.storage.local.get(["qaByOrigin"], (result) => {
        const byOrigin = result.qaByOrigin || {};
        if (message.data && message.data.length > 0) {
          byOrigin[origin] = {
            data: message.data,
            fullText: message.fullText || "",
            url: message.url,
            updatedAt: Date.now()
          };
        } else {
          delete byOrigin[origin];
        }
        chrome.storage.local.set({ qaByOrigin: byOrigin }, () => {
          resolve();
          try {
            sendResponse({ ok: true });
          } catch {
          }
        });
      });
    }));
    return true;
  }
  if (message.type === "poke-delete-origin") {
    chrome.storage.local.get(["qaByOrigin"], (result) => {
      const byOrigin = result.qaByOrigin || {};
      delete byOrigin[message.origin];
      chrome.storage.local.set({ qaByOrigin: byOrigin }, () => {
        chrome.tabs.query({}, (tabs) => {
          for (const tab of tabs) {
            if (!tab.id) continue;
            try {
              const tabOrigin = tab.url ? new URL(tab.url).origin : null;
              if (tabOrigin === message.origin) {
                chrome.tabs.sendMessage(tab.id, { type: "poke-clear-all" });
              }
            } catch {
            }
          }
        });
        sendResponse({ ok: true });
      });
    });
    return true;
  }
  if (message.type === "poke-track") {
    trackEvent(message.event, message.params || {});
    sendResponse({ ok: true });
  }
  if (message.type === "poke-get-qa") {
    chrome.storage.local.get(["qaByOrigin"], (result) => {
      sendResponse({ qaByOrigin: result.qaByOrigin || {} });
    });
    return true;
  }
  if (message.type === "poke-screenshot") {
    const windowId = sender.tab?.windowId;
    chrome.tabs.captureVisibleTab(windowId ?? chrome.windows.WINDOW_ID_CURRENT, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        sendResponse({ ok: false, error: chrome.runtime.lastError?.message || "No screenshot data" });
        return;
      }
      const hostname = message.hostname || "page";
      const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, 19);
      const filename = `poke-screenshot-${hostname}-${timestamp}.png`;
      chrome.downloads.download(
        { url: dataUrl, filename, saveAs: false },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            sendResponse({ ok: false, error: chrome.runtime.lastError.message });
          } else {
            sendResponse({ ok: true, downloadId });
          }
        }
      );
    });
    return true;
  }
});
